
  # Chhaav - your emotional shelter

  This is a code bundle for Chhaav - your emotional shelter. The original project is available at https://www.figma.com/design/pE7Gn81Asgc81ZOWUaSH5W/Chhaav---your-emotional-shelter.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  